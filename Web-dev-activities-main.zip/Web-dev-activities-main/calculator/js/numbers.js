function zero () {
    const num = document.getElementById('display').value;

    if(num != 0) {
        const newNum = num + '0';
        document.getElementById('display').value;
    }
   
}

function one () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 1;
    }
   
   else {
    const newNum = num + '1';
    document.getElementById('display').value = newNum;
   }
}

function two () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 2;
    }
   
   else {
    const newNum = num + '2';
    document.getElementById('display').value = newNum;
   }
    
}

function three () { 
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 3;
    }
   
   else {
    const newNum = num + '3';
    document.getElementById('display').value = newNum;
   }
    
}

function four () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 4;
    }
   
   else {
    const newNum = num + '4';
    document.getElementById('display').value = newNum;
   }
   
}

function five () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 5;
    }
   
   else {
    const newNum = num + '5';
    document.getElementById('display').value = newNum;
   }
   
}

function six () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 6;
    }
   
   else {
    const newNum = num + '6';
    document.getElementById('display').value = newNum;
   }
   
}

function seven () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 7;
    }
   
   else {
    const newNum = num + '7';
    document.getElementById('display').value = newNum;
   }
   
}

function eight () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 8;
    }
   
   else {
    const newNum = num + '8';
    document.getElementById('display').value = newNum;
   }
    
}

function nine () {
    const num = document.getElementById('display').value;

    if(num == 0) {
        document.getElementById('display').value = 9;
    }
   
   else {
    const newNum = num + '9';
    document.getElementById('display').value = newNum;
   }
   
}